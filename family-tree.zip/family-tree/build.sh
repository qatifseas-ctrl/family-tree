#!/usr/bin/env bash
# build.sh — Mac / Linux / WSL
# يستدعي build.py مباشرةً
set -euo pipefail
cd "$(dirname "$0")"

if   command -v python3 &>/dev/null; then PY=python3
elif command -v python  &>/dev/null; then PY=python
else echo "✖ Python غير موجود"; exit 1; fi

exec $PY build.py "$@"
