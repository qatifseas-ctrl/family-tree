#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build.py — نظام البناء الموحّد لشجرة العائلة
يُنتج نسختين من مصدر واحد:
  dist/owner/index.html                  ← نسخة المالك الكاملة
  dist/family/index.html  ← نسخة العائلة

الاستخدام:
  python3 build.py          (Mac / Linux / WSL)
  python build.py           (Windows إذا كان python3 غير متاح)
"""
import os, sys, re, hashlib, datetime, subprocess

BASE = os.path.dirname(os.path.abspath(__file__))

def read(path):
    with open(os.path.join(BASE, path), 'r', encoding='utf-8') as f:
        return f.read()

def write(path, content):
    full = os.path.join(BASE, path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(content)

def validate_js(js_text, label):
    """التحقق من صحة JS عبر Node.js"""
    import tempfile
    tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.js',
                                      delete=False, encoding='utf-8')
    tmp.write(js_text)
    tmp.close()
    try:
        r = subprocess.run(['node', '--check', tmp.name],
                           capture_output=True, text=True)
        if r.returncode != 0:
            print(f"  ✖ خطأ JS في {label}:")
            print(f"    {r.stderr.strip()[:400]}")
            return False
        return True
    except FileNotFoundError:
        print(f"  ⚠ Node.js غير موجود — تخطّي فحص JS syntax")
        return True
    finally:
        os.unlink(tmp.name)

# ══════════════════════════════════════════════════════════════════
#  قوائم ملفات JS
# ══════════════════════════════════════════════════════════════════
JS_OWNER = [
    'js/mobile.js', 'js/core.js', 'js/search.js', 'js/kinship.js',
    'js/export.js', 'js/tree.js', 'js/cloud.js', 'js/merge.js',
    'js/storage.js', 'js/supabase-sync.js', 'js/family-updates.js',
]
# العائلة: بدون supabase-sync.js (يُعيد تعريف openCloudSetup و _doUpload بنسخة Supabase)
JS_FAMILY = [
    'js/mobile.js', 'js/core.js', 'js/search.js', 'js/kinship.js',
    'js/export.js', 'js/tree.js', 'js/cloud.js', 'js/merge.js',
    'js/storage.js', 'js/family-updates.js',
]

# ══════════════════════════════════════════════════════════════════
#  تعديل core.js فقط للعائلة — بدون backreferences في الـ replacement
# ══════════════════════════════════════════════════════════════════
def patch_core_for_family(src, dev_id):
    """
    يُعدِّل core.js لنسخة العائلة.
    جميع التعديلات محصورة في هذا الملف فقط.
    لا نستخدم backreferences (\\1) في replacement strings تفادياً لأخطاء الـ escaping.
    """

    # ── 1. IS_FAMILY_COPY = true ──
    src = re.sub(
        r'(?m)^const IS_FAMILY_COPY\s*=\s*false\s*;',
        'const IS_FAMILY_COPY = true;',
        src
    )

    # ── 2. CLOUD_CONFIG — بلوك كامل فارغ ──
    src = re.sub(
        r'(?m)^const CLOUD_CONFIG\s*=\s*\{[^}]*\}',
        (
            "const CLOUD_CONFIG = {\n"
            "  KEY_HEX: '',\n"
            "  GITHUB_PAT: '',\n"
            "  GIST_ID: '',\n"
            "  GIST_FILE: 'ft_encrypted.dat',\n"
            "}"
        ),
        src
    )

    # ── 3. FAMILY_UPLOAD_CONFIG — بلوك كامل فارغ ──
    src = re.sub(
        r'(?m)^const FAMILY_UPLOAD_CONFIG\s*=\s*\{[^}]*\}',
        (
            "const FAMILY_UPLOAD_CONFIG = {\n"
            "  GITHUB_PAT: '',\n"
            "  GIST_ID: '',\n"
            "  KEY_HEX: '',\n"
            "}"
        ),
        src
    )

    # ── 4. FAMILY_DEVICE_ID — بدون backreference ──
    # نستخدم lambda بدلاً من r'\1...' لتفادي مشاكل escaping عبر المنصات
    src = re.sub(
        r'(?m)^(const FAMILY_DEVICE_ID\s*=\s*)\'[^\']*\'',
        lambda m: m.group(1) + "'" + dev_id + "'",
        src
    )

    return src

# ══════════════════════════════════════════════════════════════════
#  دالة البناء الرئيسية
# ══════════════════════════════════════════════════════════════════
def build(mode):
    """
    mode = 'OWNER' | 'FAMILY'
    يبني ملف HTML مدموجاً كاملاً ويعيد (html, js_bundle).
    """
    js_files = JS_OWNER if mode == 'OWNER' else JS_FAMILY

    html      = read('index.html')
    pwa_css   = read('pwa.css')
    styles    = read('styles.css')
    pwa_js    = read('js/pwa.js')

    # ── ضمّن CSS ──
    html = html.replace(
        '<link rel="stylesheet" href="pwa.css">',
        '<style>\n' + pwa_css + '\n</style>'
    )
    html = html.replace(
        '<link rel="stylesheet" href="styles.css">',
        '<style>\n' + styles + '\n</style>'
    )

    # ── ضمّن pwa.js ──
    html = html.replace(
        '<script src="js/pwa.js"></script>',
        '<script>\n' + pwa_js + '\n</script>'
    )

    # ── دمج ملفات JS (مع تعديل core.js للعائلة) ──
    dev_id = None
    if mode == 'FAMILY':
        dev_id = ''.join('{:02x}'.format(b) for b in os.urandom(3))
        print(f"  🔑 FAMILY_DEVICE_ID = {dev_id}")

    js_parts = ['var _HTML_TEMPLATE=document.documentElement.outerHTML;\n']
    for f in js_files:
        src = read(f)
        if f == 'js/core.js' and mode == 'FAMILY':
            src = patch_core_for_family(src, dev_id)
        js_parts.append(f'\n/* === {f} === */\n')
        js_parts.append(src)

    js_bundle = ''.join(js_parts)

    # ── تعديلات HTML للعائلة ──
    if mode == 'FAMILY':
        # حذف JSZip (غير مطلوب في نسخة العائلة)
        html = re.sub(
            r'<script[^>]*jszip[^>]*></script>\s*', '',
            html, flags=re.IGNORECASE
        )
        # إصلاح cloudSetupBanner: يحتوي display:none;...;display:flex
        # نُبقي display:none فقط لضمان إخفائه قبل أن يتدخل JS
        html = re.sub(
            r'(id="cloudSetupBanner"\s+style=")[^"]*(")',
            r'\g<1>display:none\g<2>',
            html
        )

    # ── حذف روابط <script src=...> المنفصلة ──
    for f in JS_OWNER:
        html = html.replace(f'<script src="{f}"></script>\n', '')
        html = html.replace(f'<script src="{f}"></script>', '')
    html = html.replace(
        '<script>var _HTML_TEMPLATE=document.documentElement.outerHTML;</script>\n', '')
    html = html.replace(
        '<script>var _HTML_TEMPLATE=document.documentElement.outerHTML;</script>', '')

    # ── إضافة bundle قبل </body> ──
    bundle_tag = '<script>\n' + js_bundle + '\n</script>'
    html = html.replace('</body>', bundle_tag + '\n</body>')

    return html, js_bundle


# ══════════════════════════════════════════════════════════════════
#  التحقق من الملفات المصدرية
# ══════════════════════════════════════════════════════════════════
REQUIRED = (
    ['index.html', 'pwa.css', 'styles.css'] +
    ['js/pwa.js'] + JS_OWNER
)

def check_sources():
    missing = [f for f in REQUIRED if not os.path.exists(os.path.join(BASE, f))]
    if missing:
        for m in missing:
            print(f"  ✖ مفقود: {m}")
        sys.exit(1)
    print(f"  ✔ جميع الملفات المصدرية موجودة ({len(REQUIRED)} ملفاً)")


# ══════════════════════════════════════════════════════════════════
#  Main
# ══════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print()
    print("╔══════════════════════════════════════════════════╗")
    print("║       شجرة العائلة — نظام البناء الموحّد         ║")
    print("╚══════════════════════════════════════════════════╝")
    print()

    # 1. فحص المصادر
    print("▶ التحقق من الملفات المصدرية...")
    check_sources()

    # 2. تنظيف مجلدات الإخراج
    print("▶ تنظيف مجلدات الإخراج...")
    import shutil
    for d in ['dist/owner', 'dist/family']:
        full = os.path.join(BASE, d)
        if os.path.exists(full):
            shutil.rmtree(full)
        os.makedirs(full)
    print("  ✔ مجلدات الإخراج جاهزة")

    # ══════════════════════════
    #  نسخة المالك
    # ══════════════════════════
    print()
    print("  ┌─────────────────────────────────────────────┐")
    print("  │  🔨  بناء نسخة المالك (OWNER)                │")
    print("  └─────────────────────────────────────────────┘")

    owner_html, owner_js = build('OWNER')

    # فحص JS
    print("  🔍 فحص صحة JavaScript...")
    if not validate_js(owner_js, 'نسخة المالك'):
        sys.exit(1)

    # فحص Flags
    if not re.search(r'(?m)^const IS_FAMILY_COPY\s*=\s*false\s*;', owner_html):
        print("  ✖ FATAL: IS_FAMILY_COPY ليس false في نسخة المالك!")
        sys.exit(1)
    if not re.search(r'_ftSupabaseSave', owner_html):
        print("  ✖ FATAL: supabase-sync.js مفقود من نسخة المالك!")
        sys.exit(1)

    write('dist/owner/index.html', owner_html)
    sz_o = os.path.getsize(os.path.join(BASE, 'dist/owner/index.html'))
    print(f"  ✔ dist/owner/index.html — {sz_o//1024} KB  ({len(owner_html.splitlines()):,} سطر)")

    # ══════════════════════════
    #  نسخة العائلة
    # ══════════════════════════
    print()
    print("  ┌─────────────────────────────────────────────┐")
    print("  │  🌿  بناء نسخة العائلة (FAMILY)              │")
    print("  └─────────────────────────────────────────────┘")

    family_html, family_js = build('FAMILY')

    # فحص JS
    print("  🔍 فحص صحة JavaScript...")
    if not validate_js(family_js, 'نسخة العائلة'):
        sys.exit(1)

    # فحص Flags
    if not re.search(r'(?m)^const IS_FAMILY_COPY\s*=\s*true\s*;', family_html):
        print("  ✖ FATAL: IS_FAMILY_COPY ليس true في نسخة العائلة!")
        sys.exit(1)
    if re.search(r'(?m)^const IS_FAMILY_COPY\s*=\s*false\s*;', family_html):
        print("  ✖ FATAL: IS_FAMILY_COPY = false لا يزال موجوداً في نسخة العائلة!")
        sys.exit(1)
    if re.search(r'window\._doUpload\s*=.*_ftSupabaseSave', family_html):
        print("  ✖ FATAL: supabase-sync.js موجود في نسخة العائلة — يجب إزالته!")
        sys.exit(1)

    write('dist/family/index.html', family_html)
    sz_f = os.path.getsize(os.path.join(BASE, 'dist/family/index.html'))
    print(f"  ✔ dist/family/index.html — {sz_f//1024} KB  ({len(family_html.splitlines()):,} سطر)")

    # ══════════════════════════
    #  التحقق الأخير
    # ══════════════════════════
    print()
    if sz_o > sz_f:
        print(f"  ✔ المالك ({sz_o//1024} KB) > العائلة ({sz_f//1024} KB) — فارق: +{(sz_o-sz_f)//1024} KB")
    else:
        print(f"  ⚠ تحذير: المالك ({sz_o//1024} KB) ليس أكبر من العائلة ({sz_f//1024} KB)")

    # ملخص البناء
    bt = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    summary = (
        "BUILD SUMMARY\n=============\n"
        f"Time          : {bt}\n"
        f"Owner         : dist/owner/index.html  ({sz_o//1024} KB)\n"
        f"Family        : dist/family/index.html  ({sz_f//1024} KB)\n"
        f"IS_FAMILY     : OWNER=false  FAMILY=true\n"
        f"supabase-sync : OWNER=YES  FAMILY=NO\n"
        f"Patched file  : js/core.js only (no cross-file string collisions)\n"
        f"JS validated  : node --check\n"
        f"Backref-safe  : lambda replacements (no \\\\1 escaping issues)\n"
    )
    write('dist/build_summary.txt', summary)
    print("  ✔ ملخص البناء: dist/build_summary.txt")

    print()
    print("  ════════════════════════════════════════════════")
    print("  ✅  البناء اكتمل — JavaScript صحيح تماماً!")
    print("  ════════════════════════════════════════════════")
    print()
    print("  نسخة المالك:  dist/owner/index.html")
    print("  نسخة العائلة: dist/family/index.html")
    print()
