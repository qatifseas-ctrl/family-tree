# 🌳 شجرة العائلة — نظام البناء الموحّد

## المعمارية

المشروع يعتمد **ملف مصدر واحد** لإنتاج نسختين تلقائياً:

```
src/
├── index.html          ← HTML المصدر الموحّد
├── pwa.css             ← PWA styles
├── styles.css          ← App styles  
├── js/
│   ├── core.js         ← الثوابت والـ Build Flags (IS_FAMILY_COPY, APP_MODE)
│   ├── mobile.js       ← دعم الجوال
│   ├── tree.js         ← الشجرة والـ UI (مشترك)
│   ├── search.js       ← البحث (مشترك)
│   ├── kinship.js      ← كاشف القرابة (مشترك)
│   ├── export.js       ← التصدير (مشترك + أدوات المالك)
│   ├── storage.js      ← التخزين المحلي + FSA
│   ├── cloud.js        ← GitHub Gist (مشترك مع فرق في السلوك)
│   ├── merge.js        ← الدمج + exportFamilyCopy (مالك فقط)
│   ├── supabase-sync.js← Supabase (مالك فقط بحكم الإعدادات)
│   ├── family-updates.js← نظام تحديثات العائلة
│   └── pwa.js          ← Service Worker + Install Prompt
├── build.sh            ← بناء Mac/Linux/WSL
├── build.ps1           ← بناء Windows PowerShell
└── dist/               ← الملفات المُنتجة (مُستبعد من git)
    ├── owner/index.html
    ├── family/index_Family_Version.html
    └── build_summary.txt
```

---

## البناء

### Mac / Linux / WSL
```bash
bash build.sh
```

### Windows
```powershell
Set-ExecutionPolicy Bypass -Scope Process; .\build.ps1
```

---

## الناتج

| الملف | الوصف |
|-------|-------|
| `dist/owner/index.html` | نسخة المالك الكاملة — ارفعها على GitHub Pages |
| `dist/family/index_Family_Version.html` | نسخة العائلة — وزّعها على أفراد العائلة |

---

## Build Flags

المتغير الرئيسي في `js/core.js`:

```javascript
const IS_FAMILY_COPY = false;  // المصدر دائماً false
```

يُعدَّل تلقائياً أثناء البناء:

| النسخة | IS_FAMILY_COPY | CLOUD_CONFIG | FAMILY_UPLOAD_CONFIG |
|--------|---------------|--------------|----------------------|
| المالك | `false` | كامل (المالك يملؤه) | كامل |
| العائلة | `true` | **فارغ** (أمان) | فارغ (يُملأ من JSON) |

---

## التطوير المستقبلي

**أي تعديل على UI أو ميزة مشتركة → عدّل الملف المصدر مرة واحدة ثم أعد البناء.**

- تعديل التصميم → `styles.css` أو `pwa.css`
- تعديل الشجرة → `js/tree.js`
- تعديل البحث → `js/search.js`
- إضافة ميزة جديدة → أضفها في الملف المناسب
- ميزة للمالك فقط → احتها داخل `if (!IS_FAMILY_COPY) { ... }`
- ميزة للعائلة فقط → احتها داخل `if (IS_FAMILY_COPY) { ... }`

بعد أي تعديل: `bash build.sh` (أو `.\build.ps1` على Windows).

---

## نشر نسخة المالك

```
dist/owner/index.html
+ sw.js
+ manifest.json
+ icons/
```

## توزيع نسخة العائلة

```
dist/family/index_Family_Version.html
+ sw.js
+ manifest.json
+ icons/
```

أو شارك الملف `index_Family_Version.html` مباشرة (يعمل بدون رفع).
