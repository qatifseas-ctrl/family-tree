var _HTML_TEMPLATE=document.documentElement.outerHTML;

/* ══════════════════════════════════════════════════════════
   وضع الجوال — Mobile Mode System
══════════════════════════════════════════════════════════ */
const MOB_KEY='ft_mobile_mode_v1';
let _mobileMode=false;
let _mobSheetPersonId=null;

function _isMobileDevice(){
  return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)||window.innerWidth<640;
}

function initMobileMode(){
  // استعادة الحالة المحفوظة
  try{
    let saved=localStorage.getItem(MOB_KEY);
    if(saved==='1')_mobileMode=true;
    else if(saved===null&&_isMobileDevice())_mobileMode=true; // تفعيل تلقائي على الجوال
  }catch(e){}
  _applyMobileMode();
}

function toggleMobileMode(){
  _mobileMode=!_mobileMode;
  try{localStorage.setItem(MOB_KEY,_mobileMode?'1':'0');}catch(e){}
  _applyMobileMode();
  renderAll();
}

function _applyMobileMode(){
  document.body.classList.toggle('mobile-mode',_mobileMode);
  let btn=document.getElementById('mobileModeBtn');
  if(!btn)return;
  if(_mobileMode){
    btn.classList.add('active');
    btn.innerHTML='📱 جوال ✓';
    btn.title='إلغاء وضع الجوال';
  } else {
    btn.classList.remove('active');
    btn.innerHTML='📱 وضع الجوال';
    btn.title='وضع الجوال: شجرة أخف وأسرع';
  }
}

// تبديل فتح/إغلاق فرع في وضع الجوال (بدون إغلاق الإخوة)
function toggleNodeMobile(id){
  expanded[id]=!expanded[id];
  renderAll();
}

// Action Sheet — إجراءات الشخص في وضع الجوال
function openMobSheet(id){
  _mobSheetPersonId=id;
  let p=getPerson(id);if(!p)return;
  let sheet=document.getElementById('mob-action-sheet');
  let overlay=document.getElementById('mob-action-sheet-overlay');
  let nameEl=document.getElementById('mob-sheet-name');
  let btnsEl=document.getElementById('mob-sheet-btns');
  if(!sheet||!overlay)return;
  nameEl.textContent=p.name+(p.familyName?' '+p.familyName:'');
  let hasChildren=getChildrenForNode(id).length>0;
  let isExtFemale=(p.isExternal===true&&p.gender==='female');
  let btns=[
    {icon:'📋',label:'البيانات',action:`closeMobSheet();showPersonDetail(${id})`},
    {icon:'✏️',label:'تعديل',action:`closeMobSheet();openEditModal(${id})`},
    ...(isExtFemale?[]:[{icon:'➕',label:'إضافة ابن',action:`closeMobSheet();openAddModal(${id})`}]),
    {icon:'🌳',label:'انتقال',action:`closeMobSheet();navigateToPerson(${id})`},
  ];
  if(p.parentId) btns.splice(isExtFemale?2:3,0,{icon:'👥',label:'إضافة أخ/أخت',action:`closeMobSheet();openAddModal(${p.parentId})`});
  if(p.isExternal===true&&!p.parentId) btns.splice(isExtFemale?2:3,0,{icon:'👨‍👩‍👦',label:'إضافة والد/والدة',action:`closeMobSheet();openAddParentModal(${id})`});
  if(hasChildren) btns.push({icon:'⇅',label:'الترتيب',action:`closeMobSheet();openReorderModal(${id})`});
  btns.push({icon:'🗑',label:'حذف',action:`closeMobSheet();confirmDeleteFromList(${id})`,cls:'danger'});
  btnsEl.innerHTML=btns.map(b=>`
    <div class="sheet-btn${b.cls?' '+b.cls:''}" onclick="${b.action}">
      <span class="sh-icon">${b.icon}</span>
      <span class="sh-label">${b.label}</span>
    </div>`).join('');
  overlay.classList.add('open');
  sheet.classList.add('open');
  // إغلاق بالسحب للأسفل
  _mobSheetSwipe(sheet);
}

function closeMobSheet(){
  let sheet=document.getElementById('mob-action-sheet');
  let overlay=document.getElementById('mob-action-sheet-overlay');
  if(sheet)sheet.classList.remove('open');
  if(overlay)overlay.classList.remove('open');
  // إغلاق أزرار الإجراءات المفتوحة
  document.querySelectorAll('.node-header.actions-open').forEach(el=>el.classList.remove('actions-open'));
}

function _mobSheetSwipe(el){
  let startY=0,dragging=false;
  el.onpointerdown=e=>{startY=e.clientY;dragging=true;el.style.transition='none';};
  el.onpointermove=e=>{
    if(!dragging)return;
    let dy=Math.max(0,e.clientY-startY);
    el.style.transform=`translateY(${dy}px)`;
  };
  el.onpointerup=e=>{
    el.style.transition='';el.style.transform='';dragging=false;
    if(e.clientY-startY>80)closeMobSheet();
  };
}

/* ══════════════════════════════════════════════════════════
   THEME SYSTEM — Light / Dark only
   يُطبَّق على <html> عبر data-theme="light"|"dark"
   - First launch: detects system preference and saves it.
   - Subsequent launches: loads saved preference directly.
   - Toggle button shows the OPPOSITE theme icon (click to switch).
   - Icons are embedded inline SVG — no external URL dependency.
══════════════════════════════════════════════════════════ */
(function(){
  var THEME_KEY='ft_theme_v1';

  // ── Inline SVG icons — fully self-contained, no network request ──
  // Sun icon: shown when dark mode is active (click to go light)
  var ICON_SUN='<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>';
  // Moon icon: shown when light mode is active (click to go dark)
  var ICON_MOON='<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';

  var _current='light';

  function applyTheme(theme){
    _current=theme;
    var html=document.documentElement;
    html.setAttribute('data-theme',theme);
    html.style.colorScheme=theme;

    // Update <meta name="theme-color"> for mobile browser chrome
    var metaTheme=document.querySelector('meta[name="theme-color"]');
    if(metaTheme)metaTheme.setAttribute('content',theme==='dark'?'#1f2937':'#3b82f6');

    try{localStorage.setItem(THEME_KEY,theme);}catch(e){}
    updateBtn();
  }

  function updateBtn(){
    var btn=document.getElementById('themeToggleBtn');
    var iconEl=document.getElementById('themeToggleIcon');
    if(!btn||!iconEl)return;

    var isDark=_current==='dark';
    // Show the OPPOSITE icon — pressing it switches to that theme
    if(isDark){
      iconEl.innerHTML=ICON_SUN;
      btn.title='التبديل إلى الوضع الفاتح';
    } else {
      iconEl.innerHTML=ICON_MOON;
      btn.title='التبديل إلى الوضع الداكن';
    }

    // Visual feedback for current dark state
    btn.style.background=isDark?'#374151':'';
    btn.style.borderColor=isDark?'#4b5563':'';
    // Tint the SVG stroke/fill to match theme
    var svgEl=iconEl.querySelector('svg');
    if(svgEl) svgEl.style.color=isDark?'#fbbf24':'#374151';
  }

  // Toggle between light and dark
  window.toggleTheme=function(){
    applyTheme(_current==='dark'?'light':'dark');
  };

  // Keep legacy cycleTheme alias in case anything else calls it
  window.cycleTheme=window.toggleTheme;

  // Init: load saved preference or detect system theme on first launch
  var saved=null;
  try{saved=localStorage.getItem(THEME_KEY);}catch(e){}

  if(saved==='light'||saved==='dark'){
    // User has an explicit saved preference — use it directly
    applyTheme(saved);
  } else {
    // First launch: detect system theme and save it as the initial preference
    var prefersDark=false;
    try{prefersDark=window.matchMedia('(prefers-color-scheme:dark)').matches;}catch(e){}
    applyTheme(prefersDark?'dark':'light');
  }

  // Update button once DOM is ready (button may not exist at script run time)
  document.addEventListener('DOMContentLoaded',updateBtn);
  window.addEventListener('load',updateBtn);
  setTimeout(updateBtn,200);
})();
