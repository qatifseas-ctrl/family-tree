# build.ps1 — Windows PowerShell
# يستدعي build.py مباشرةً
# الاستخدام: Set-ExecutionPolicy Bypass -Scope Process; .\build.ps1

Set-Location $PSScriptRoot

$py = $null
foreach ($cmd in @('python3','python')) {
    if (Get-Command $cmd -ErrorAction SilentlyContinue) { $py = $cmd; break }
}
if (-not $py) { Write-Host "✖ Python غير موجود" -ForegroundColor Red; exit 1 }

& $py build.py
